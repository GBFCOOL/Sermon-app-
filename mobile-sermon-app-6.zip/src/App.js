import React, { useState, useEffect } from 'react';

export default function SermonApp() {
  const [sermons, setSermons] = useState([]);
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState('John 3:16');
  const [scripture, setScripture] = useState(null);
  const [presentMode, setPresentMode] = useState(false);

  const { loadVerse, loadChapter, getChapterCount, books } = useBible();

  useEffect(() => {
    resetSermons();
  }, []);

  async function resetSermons() {
    try {
      const res = await fetch('/data/sample-sermons.json');
      if (res.ok) {
        const data = await res.json();
        setSermons(data);
        setSelected(data[0]);
      }
    } catch (err) {
      console.error("Failed to load sample sermons", err);
    }
  }

  async function fetchScripture(reference) {
    setScripture({ loading: true });
    try {
      if (/\d:\d/.test(reference)) {
        const text = await loadVerse(reference);
        if (text) {
          setScripture({
            type: 'verse',
            text,
            plainText: text,
            ref: reference,
            meta: { version: 'WEB', copyright: 'Public Domain' }
          });
        } else {
          setScripture({ error: 'Verse not found' });
        }
      } else {
        const [book, chap] = reference.split(/\s+/);
        const verses = await loadChapter(book, chap);
        if (verses && Object.keys(verses).length > 0) {
          setScripture({
            type: 'chapter',
            ref: `${book} ${chap}`,
            book: book.toLowerCase(),
            chapter: parseInt(chap, 10),
            verses,
            meta: { version: 'WEB', copyright: 'Public Domain' }
          });
        } else {
          setScripture({ error: 'Chapter not found' });
        }
      }
    } catch (err) {
      setScripture({ error: err.message });
    }
  }

  function createSermon() {
    const s = { id: Date.now(), title: 'Untitled Sermon', notes: '' };
    setSermons([s, ...sermons]);
    setSelected(s);
  }

  function saveSermon(updated) {
    setSermons(sermons.map(s => (s.id === updated.id ? updated : s)));
    setSelected(updated);
  }

  async function goToChapter(book, chap) {
    const verses = await loadChapter(book, chap);
    if (verses && Object.keys(verses).length > 0) {
      setScripture({
        type: 'chapter',
        ref: `${capitalize(book)} ${chap}`,
        book: book.toLowerCase(),
        chapter: chap,
        verses,
        meta: { version: 'WEB', copyright: 'Public Domain' }
      });
      setQuery(`${capitalize(book)} ${chap}`);
    }
  }

  async function goPrev() {
    if (!scripture?.book || !scripture?.chapter) return;
    const currentIndex = books.indexOf(scripture.book);
    if (scripture.chapter > 1) {
      goToChapter(scripture.book, scripture.chapter - 1);
    } else if (currentIndex > 0) {
      const prevBook = books[currentIndex - 1];
      const lastChap = await getChapterCount(prevBook);
      goToChapter(prevBook, lastChap);
    }
  }

  async function goNext() {
    if (!scripture?.book || !scripture?.chapter) return;
    const currentIndex = books.indexOf(scripture.book);
    const totalChaps = await getChapterCount(scripture.book);
    if (scripture.chapter < totalChaps) {
      goToChapter(scripture.book, scripture.chapter + 1);
    } else if (currentIndex < books.length - 1) {
      const nextBook = books[currentIndex + 1];
      goToChapter(nextBook, 1);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6 font-sans">
      <div className="max-w-6xl mx-auto grid grid-cols-12 gap-6">
        <aside className="col-span-3 bg-white rounded-2xl p-4 shadow">
          <h2 className="text-lg font-semibold">Sermons</h2>
          <button className="mt-3 w-full py-2 rounded-lg border" onClick={createSermon}>New Sermon</button>
          <button className="mt-2 w-full py-2 rounded-lg border text-sm text-gray-600" onClick={resetSermons}>↺ Reset to Samples</button>
          <div className="mt-4 space-y-2">
            {sermons.map(s => (
              <div key={s.id} onClick={() => setSelected(s)} className={`p-2 rounded-md cursor-pointer ${selected?.id === s.id ? 'bg-indigo-50' : 'hover:bg-gray-100'}`}>
                <div className="font-medium">{s.title}</div>
                <div className="text-sm text-gray-500 truncate">{s.notes?.slice(0, 80)}</div>
              </div>
            ))}
          </div>
        </aside>

        <main className="col-span-6 bg-white rounded-2xl p-4 shadow">
          <div className="flex items-center justify-between">
            <div>
              <input className="text-2xl font-semibold w-full bg-transparent outline-none" value={selected?.title || ''} onChange={e => saveSermon({ ...selected, title: e.target.value })} placeholder="Sermon title" />
              <div className="text-sm text-gray-500">Drafts auto-save locally in this demo</div>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-2 rounded-lg border" onClick={() => setPresentMode(!presentMode)}>
                {presentMode ? 'Exit Presentation' : 'Presentation Mode'}
              </button>
            </div>
          </div>

          {!presentMode && (
            <div className="mt-4">
              <textarea rows={12} className="w-full p-3 rounded-lg border resize-y" value={selected?.notes || ''} onChange={e => saveSermon({ ...selected, notes: e.target.value })} placeholder="Write your sermon notes here..." />
            </div>
          )}

          {presentMode && (
            <div className="mt-4 p-6 rounded-lg bg-black text-white min-h-[320px] flex items-center justify-center">
              <div className="max-w-3xl text-center">
                <h1 className="text-4xl font-bold mb-4">{selected?.title}</h1>
                <p className="whitespace-pre-wrap text-lg">{selected?.notes}</p>
              </div>
            </div>
          )}
        </main>

        <section className="col-span-3 bg-white rounded-2xl p-4 shadow">
          <h3 className="font-semibold">Scripture Lookup</h3>
          <div className="mt-2">
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="e.g. John 3:16 or Psalm 23" className="w-full p-2 rounded-lg border" />
            <button className="mt-2 w-full py-2 rounded-lg bg-indigo-600 text-white" onClick={() => fetchScripture(query)}>Fetch Scripture</button>
          </div>

          <div className="mt-4 overflow-auto max-h-80">
            {scripture?.loading && <div>Loading...</div>}
            {scripture?.error && <div className="text-red-500">{scripture.error}</div>}

            {scripture?.type === 'verse' && (
              <div className="prose max-w-none">
                <div>{scripture.text}</div>
                <div className="text-xs text-gray-400 mt-2">WEB — Public Domain</div>
                <button className="mt-3 px-3 py-2 rounded-md border" onClick={() => saveSermon({ ...selected, notes: selected.notes + '\n\n' + (scripture.plainText || '') })}>Insert into Notes</button>
              </div>
            )}

            {scripture?.type === 'chapter' && (
              <div className="prose max-w-none">
                <h4 className="font-semibold mb-2">{scripture.ref}</h4>
                <div className="space-y-1">
                  {Object.entries(scripture.verses).map(([ref, text]) => (
                    <div key={ref} className="hover:bg-gray-50 p-1 rounded cursor-pointer" onClick={() => saveSermon({ ...selected, notes: selected.notes + `\n${ref} ${text}` })}>
                      <span className="font-semibold">{ref}</span> {text}
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-4">
                  <button className="px-3 py-2 rounded-md border" disabled={scripture.book === 'genesis' && scripture.chapter === 1} onClick={goPrev}>◀ Prev Chapter</button>
                  <button className="px-3 py-2 rounded-md border" disabled={scripture.book === 'revelation' && scripture.chapter === 22} onClick={goNext}>Next Chapter ▶</button>
                </div>
                <button className="mt-3 px-3 py-2 rounded-md border" onClick={() => saveSermon({ ...selected, notes: selected.notes + `\n\n${Object.entries(scripture.verses).map(([r,t]) => r + ' ' + t).join('\n')}` })}>Insert Whole Chapter</button>
                <div className="text-xs text-gray-400 mt-2">WEB — Public Domain</div>
              </div>
            )}
          </div>
        </section>
      </div>

      <footer className="max-w-6xl mx-auto mt-6 text-sm text-gray-500">
        <div>Demo sermon app • Uses World English Bible (WEB, Public Domain)</div>
      </footer>
    </div>
  );
}

function useBible() {
  const [cache, setCache] = useState({});
  const [master, setMaster] = useState(null);

  const books = [ 'genesis','exodus','leviticus','numbers','deuteronomy','joshua','judges','ruth','1samuel','2samuel','1kings','2kings','1chronicles','2chronicles','ezra','nehemiah','esther','job','psalms','proverbs','ecclesiastes','songofsolomon','isaiah','jeremiah','lamentations','ezekiel','daniel','hosea','joel','amos','obadiah','jonah','micah','nahum','habakkuk','zephaniah','haggai','zechariah','malachi','matthew','mark','luke','john','acts','romans','1corinthians','2corinthians','galatians','ephesians','philippians','colossians','1thessalonians','2thessalonians','1timothy','2timothy','titus','philemon','hebrews','james','1peter','2peter','1john','2john','3john','jude','revelation' ];

  async function loadBook(book) {
    if (!cache[book]) {
      try {
        const res = await fetch(`/bible/${book}.json`);
        const data = await res.json();
        setCache(prev => ({ ...prev, [book]: data }));
        return data;
      } catch {
        if (!master) {
          const res = await fetch('/bible-web.json');
          const data = await res.json();
          setMaster(data);
          return data;
        }
        return master;
      }
    }
    return cache[book];
  }

  async function loadVerse(ref) {
    const [book, rest] = ref.toLowerCase().split(/\s+/);
    if (!book || !rest) return null;
    const bookData = await loadBook(book);
    if (!bookData) return null;
    return bookData[`${book} ${rest}`] || (master ? master[`${book} ${rest}`] : null);
  }

  async function loadChapter(book, chap) {
    const bookKey = book.toLowerCase();
    const bookData = await loadBook(bookKey);
    if (!bookData) return null;
    const verses = {};
    Object.keys(bookData)
      .filter(k => k.startsWith(`${bookKey} ${chap}:`))
      .forEach(k => { verses[k] = bookData[k]; });
    return verses;
  }

  async function getChapterCount(book) {
    const bookKey = book.toLowerCase();
    const bookData = cache[bookKey] || master;
    if (!bookData) {
      const loaded = await loadBook(bookKey);
      if (!loaded) return null;
      return new Set(Object.keys(loaded).map(k => k.split(" ")[1].split(":")[0])).size;
    }
    const chapters = new Set(Object.keys(bookData).map(k => k.split(" ")[1].split(":")[0]));
    return chapters.size;
  }

  return { loadVerse, loadChapter, getChapterCount, books };
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
